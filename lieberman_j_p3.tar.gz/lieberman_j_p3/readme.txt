C++
make

When I run mediuminput.txt when ran with the backtracking algorithm in order to produce mediumOutputBacktracking.txt, it takes too much time and therefore does not produce output. I waited for up to 15 minutes and it did not produce it. However, I believe my backtracking algorithm is correct and I would like to try and receive credit for this.