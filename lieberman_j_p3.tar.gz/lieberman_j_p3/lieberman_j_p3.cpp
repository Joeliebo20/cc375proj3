#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
#include <math.h>
#include <time.h>
#include <array>
#include <bits/stdc++.h>
#include <time.h>

using namespace std;

int maxProf = 0;
vector<int> vec;

struct item {
    int weight;
    int profit;
    bool operator== (const item &i){
        return (this->weight == i.weight && this->profit == i.profit);
    }
};

vector<item> parseInput(string input){
    ifstream f;
    f.open(input);
    struct item i;
    vector<item> cards;
    int capac;
    int num_items;
    while(f >> num_items >> capac) {
        break;
    }
    while(f >> i.weight >> i.profit) {
        cards.push_back(i);
    }
    i.weight = num_items;
    i.profit = capac;
    cards.push_back(i);
    return cards;
}

void output(ofstream& out, vector<item> cards, double time, vector<int> indexes){
    int size  = cards.size();
    int total_weight = 0;
    for(int i = 0; i < cards.size(); i++) {
        total_weight += cards.at(i).profit;
    }
    stringstream ss;
    stringstream ss2;
    for(int i = 0; i < indexes.size(); i++) {
        ss2 << indexes.at(i) << " ";
    }
    ss << size << " " << total_weight << " " << time << " " << ss2.str();
    out << ss.str();
    
}

vector<item> greedy1(vector<item> c, vector<item> ksack, string outFile, struct item item){
    time_t start = time(0);
    vector<int> ratios;
    vector<int> indexes;
    int curr_total = 0;
    for(int i = 0; i < c.size(); i++) {
        int ratio = c.at(i).profit / c.at(i).weight;
        ratios.push_back(ratio);
    }
    //sorts the ratios of them in order
    sort(ratios.begin(), ratios.end(), greater<int>());
    
    for(int i = 0; i < c.size(); i++) {
        if(find(ratios.begin(), ratios.end(), (c.at(i).profit / c.at(i).weight)) != ratios.end()) {
            //if the weight + current total is less than capacity and the size of the knapsack is less than the total allowed size
            if((c.at(i).weight + curr_total) <= item.profit && (ksack.size() <= item.weight - 1)) {
                ksack.push_back(c.at(i));
                indexes.push_back(i);
                curr_total += c.at(i).weight;
            }
        }
    }
    time_t end = time(0);
    double time = difftime(end, start) * 1000.0;
    ofstream out;
    out.open(outFile);
    output(out, ksack, time, indexes);
    return ksack;
}

int maxElement(vector<item> cards, int capacity){
    int max = 0;
    for(int i = 0; i < cards.size(); i++) {
        if(max < cards.at(i).profit) {
            max = cards.at(i).profit;
        }
    }
    return max;
}

void greedy2(vector<item> c, vector<item> ksack, string outFile, struct item first){
    time_t start = time(0);
    vector<item> g1knapsack = greedy1(c, ksack, outFile, first);
    vector<item> knapsack;
    vector<int> indexes;
    int profit = 0;
    int pmax;
    ofstream out;
    out.open(outFile);
    for(int i = 0; i < g1knapsack.size(); i++) {profit += g1knapsack.at(i).profit;}
    pmax = maxElement(c, first.profit);
    if(profit > pmax) {
        for(int i = 0; i < c.size(); i++) {
            if(find(g1knapsack.begin(), g1knapsack.end(), c.at(i)) != g1knapsack.end()) {
                indexes.push_back(i);
            }
        }
        time_t end2 = time(0);
        double time2 = difftime(end2, start) * 1000.0;
        output(out, g1knapsack, time2, indexes);
        //return g1knapsack;
    }
    else {
        for(int i = 0; i < c.size(); i++) {
            if(pmax == c.at(i).profit) {
                knapsack.push_back(c.at(i));
                indexes.push_back(i);
            }
        }
        time_t end = time(0);
        double time = difftime(end, start) * 1000.0;
        output(out, knapsack, time, indexes);
        //return knapsack;
    }
}

int computeUpperBound(int index, int weight, int profit, int capacity, int size, vector<item> cards) {
    int bound = profit;
    vector<float> x(size+1, 0);
    //vector<int> temp;
    while((weight <= capacity) && (index < size)) {
        if(weight += cards.at(index).weight <= capacity) {
            x[index] = 1;
            weight += cards.at(index).weight;
            bound += cards.at(index).profit;
        }
        else {
            x[index] = float((capacity - weight)) / float(cards.at(index).weight);
            weight = capacity;
            bound = bound + ((cards.at(index).profit)*(x[index]));
        }
        index++;
    }
    return bound;
}

bool promising(int index, int weight, int profit, int capacity, int size, vector<item> cards){
    if(weight >= capacity) {return false;}
    int bound = computeUpperBound(index+1, weight, profit, capacity, size, cards);
    if(bound > profit) {
        return true;
    }
    else {
        return false;
    }
}

void knapsack(int index, int profit, int weight, int numbest, int bestset[], int include[], int capacity, vector<item> cards, int size, ofstream &out) {
    //cout << maxProfit << endl;
    if(weight <= capacity && profit > maxProf) {
        maxProf = profit;
        numbest = index;
        bestset = include;
        for(int i = 0; i < size; i++) {
            vec.push_back(bestset[i]);
        }
    }
    if(promising(index, weight, profit, capacity, size, cards)) {
        include[index + 1] = 1;
        knapsack(index + 1, profit + cards.at(index+1).profit, weight + cards.at(index+1).weight, numbest, bestset, include, capacity, cards, size, out);
        include[index + 1] = 0;
        knapsack(index + 1, profit, weight, numbest, bestset, include, capacity, cards, size, out);
    }
}

void backtrackingAlg(vector<item> cards, vector<item> ksack, string outputFile, struct item first) {
    time_t start = time(0);
    vector<int> ratios;
    struct item temp;
    int size = cards.size();
    int index = -1;
    ofstream out;
    stringstream ss;
    out.open(outputFile);
    for(int i = 0; i < cards.size(); i++) {
        int ratio = cards.at(i).profit / cards.at(i).weight;
        ratios.push_back(ratio);
    }
    //sorts the ratios of them in order
    sort(ratios.begin(), ratios.end(), greater<int>());
    int capacity = first.profit;
    int weight = 0;
    int prof = 0;
    vector<int> indexes;
    int include[size];
    int bestSet[size];
    for(int i = 0; i < size; i++) {
        include[i] = 0;
        bestSet[i] = 0;
    }
    int numBest = 0;
    int maxProfit = 0;
    
    knapsack(index, weight, prof, numBest, bestSet, include, capacity, cards, size, out);
    for(int i = 0; i < vec.size(); i++) {
        ss << vec.at(i);
    }
    string ans = ss.str();
    string new_str = ans.substr(ans.size() - size, ans.size());
    for(int i = 0; i < new_str.size(); i++) {
        if(new_str.at(i) == '1') {
            //push back into the container that stoes every item thats good
            indexes.push_back(i);
        }
    }
    for(int i = 0; i < indexes.size(); i++) {
        ksack.push_back(cards.at(indexes.at(i)));
    }
    time_t end = time(0);
    double time = difftime(end, start) * 1000.0;
    output(out, ksack, time, indexes);
    
    //compute upper bound
}


int main(int argc, char* argv[]){
    string inFile(argv[1]);
    string outFile(argv[2]);
    string algorithm(argv[3]);

    struct item first;
    vector<item> knapsack;
    vector<item> cards = parseInput(inFile); 
    //first is the "first input" aka the amount of cards and total capacity
    first = cards.at(cards.size() - 1);
    cards.pop_back();
    if(stoi(algorithm) == 0) {
        greedy1(cards, knapsack, outFile, first);
    }
    else if(stoi(algorithm) == 1) {
        greedy2(cards, knapsack, outFile, first);
    }
    else {
        backtrackingAlg(cards, knapsack, outFile, first);
    }
    //0 = greedy1, 1 = greedy2, 2 = backtracking
}